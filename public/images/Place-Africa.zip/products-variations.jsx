// Products section variations — Docaya showcase
// A. Vertical tabs (Stripe/Linear style) — auto-advancing steps + big visual
// B. Horizontal marquee of mockups with caption highlight
// C. Stacked phone carousel with Auto insurance story

const PBRAND = { accent: "#FE1B00", accent2: "#FE4D2B" };

const STORY_STEPS = [
  {
    id: 'chat',
    num: '01',
    title: "Le client entre par WhatsApp",
    desc: "Un lien unique ou un QR code déclenche la conversation. L'IA qualifie la demande en quelques secondes.",
    image: 'assets/Picture3.png',
    chip: 'Conversation · WhatsApp',
  },
  {
    id: 'form',
    num: '02',
    title: "Il choisit sa formule en 3 écrans",
    desc: "Formule, récapitulatif, paiement. Wave, Orange Money, MTN Momo ou carte — tout se règle dans la conversation.",
    image: 'assets/Picture5.png',
    chip: 'Souscription · Paiement',
  },
  {
    id: 'inbox',
    num: '03',
    title: "Vos équipes gèrent depuis un seul écran",
    desc: "Tickets, devis, contrats. Tout remonte dans Docaya avec les apporteurs, le statut, les notes — prêt pour l'action.",
    image: 'assets/Picture4.png',
    chip: 'Back-office · Tickets',
  },
  {
    id: 'kpi',
    num: '04',
    title: "Vous pilotez les résultats",
    desc: "Acquisition, conversion, paiement — les KPI en temps réel par canal et par apporteur.",
    image: 'assets/Picture6.png',
    chip: 'Analytique · Pilotage',
  },
];

// ── Version A — Vertical tabs with auto-advance ────────────
function ProductsA() {
  const [active, setActive] = React.useState(0);
  const [paused, setPaused] = React.useState(false);
  const rootRef = React.useRef(null);

  React.useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setActive((i) => (i + 1) % STORY_STEPS.length), 4200);
    return () => clearInterval(t);
  }, [paused]);

  return (
    <section
      ref={rootRef}
      className="bg-neutral-50 py-20 px-8"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="max-w-6xl mx-auto">
        <div className="mb-12">
          <span className="inline-block text-xs font-bold uppercase tracking-widest mb-4" style={{color: PBRAND.accent}}>
            Notre produit — Docaya en action
          </span>
          <h2 className="text-4xl font-bold text-neutral-900 mb-3 max-w-3xl leading-[1.1] tracking-tight">
            D'un message WhatsApp à l'encaissement, un seul outil.
          </h2>
          <p className="text-neutral-500 max-w-2xl text-lg">
            Exemple : un parcours d'assurance auto, de la première question du prospect jusqu'au paiement Wave.
          </p>
        </div>

        <div className="grid lg:grid-cols-[380px_1fr] gap-10 items-start">
          {/* Steps */}
          <div className="flex flex-col gap-2">
            {STORY_STEPS.map((s, i) => {
              const isActive = i === active;
              return (
                <button
                  key={s.id}
                  onClick={() => setActive(i)}
                  className="text-left relative overflow-hidden rounded-2xl transition-all duration-300 group"
                  style={{
                    padding: '18px 20px 20px',
                    background: isActive ? 'white' : 'transparent',
                    border: isActive ? '1px solid #E5E5E5' : '1px solid transparent',
                    boxShadow: isActive ? '0 1px 4px rgba(0,0,0,0.06)' : 'none',
                  }}
                >
                  {/* Progress bar */}
                  {isActive && !paused && (
                    <div
                      className="absolute bottom-0 left-0 h-[3px]"
                      style={{
                        background: PBRAND.accent,
                        width: '100%',
                        transformOrigin: 'left',
                        animation: 'progressBar 4.2s linear forwards',
                      }}
                    />
                  )}
                  <div className="flex items-baseline gap-3 mb-1.5">
                    <span
                      className="text-xs font-mono font-bold tabular-nums"
                      style={{color: isActive ? PBRAND.accent : '#A3A3A3'}}
                    >
                      {s.num}
                    </span>
                    <span className={`text-base font-bold ${isActive ? 'text-neutral-900' : 'text-neutral-500 group-hover:text-neutral-800'} transition-colors`}>
                      {s.title}
                    </span>
                  </div>
                  <p className={`text-sm leading-relaxed ${isActive ? 'text-neutral-600' : 'text-neutral-400'} transition-colors pl-7`}>
                    {s.desc}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Big visual */}
          <div className="relative">
            <div className="relative aspect-[5/4] rounded-3xl overflow-hidden bg-white border border-neutral-200 shadow-xl">
              {/* Ambient glow */}
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-1/2 left-1/2 w-[70%] h-[70%] -translate-x-1/2 -translate-y-1/2 rounded-full blur-[80px] opacity-20"
                  style={{background: `radial-gradient(circle, ${PBRAND.accent} 0%, transparent 70%)`}} />
              </div>

              {/* Chip */}
              <div className="absolute top-5 left-5 z-20">
                <div
                  key={active + '-chip'}
                  className="inline-flex items-center gap-2 bg-neutral-900 text-white text-xs font-semibold px-3 py-1.5 rounded-full"
                  style={{animation: 'chipIn 0.45s cubic-bezier(.2,.8,.3,1) both'}}
                >
                  <span className="w-1.5 h-1.5 rounded-full" style={{background: PBRAND.accent}} />
                  {STORY_STEPS[active].chip}
                </div>
              </div>

              {/* Image crossfade */}
              {STORY_STEPS.map((s, i) => (
                <img
                  key={s.id}
                  src={s.image}
                  alt={s.title}
                  className="absolute inset-0 w-full h-full object-contain p-6 transition-all duration-[650ms]"
                  style={{
                    opacity: i === active ? 1 : 0,
                    transform: i === active ? 'translateY(0) scale(1)' : 'translateY(10px) scale(0.97)',
                  }}
                />
              ))}
            </div>

            {/* Bottom step dots */}
            <div className="flex items-center justify-center gap-1.5 mt-6">
              {STORY_STEPS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  className="h-1.5 rounded-full transition-all"
                  style={{
                    width: i === active ? 28 : 8,
                    background: i === active ? PBRAND.accent : '#D4D4D4',
                  }}
                />
              ))}
            </div>
          </div>
        </div>

        <style>{`
          @keyframes progressBar { from { transform: scaleX(0); } to { transform: scaleX(1); } }
          @keyframes chipIn {
            0% { opacity: 0; transform: translateY(-6px); }
            100% { opacity: 1; transform: translateY(0); }
          }
        `}</style>
      </div>
    </section>
  );
}

// ── Version B — Mosaïque orchestrée (hero + 3 tuiles) ──────
function ProductsB() {
  return (
    <section className="bg-neutral-50 py-20 px-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-12 grid lg:grid-cols-2 gap-10 items-end">
          <div>
            <span className="inline-block text-xs font-bold uppercase tracking-widest mb-4" style={{color: PBRAND.accent}}>
              Notre produit
            </span>
            <h2 className="text-4xl font-bold text-neutral-900 leading-[1.1] tracking-tight">
              Une plateforme. Tous les canaux. Zéro friction.
            </h2>
          </div>
          <p className="text-neutral-500 text-lg">
            Docaya réunit WhatsApp, SMS, e-mail, voix et paiement mobile dans un seul outil — conçu pour les équipes commerciales, SAV et marketing africaines.
          </p>
        </div>

        {/* Big tile */}
        <div className="rounded-3xl bg-white border border-neutral-200 overflow-hidden mb-6 relative"
          style={{boxShadow: '0 1px 4px rgba(0,0,0,0.06)'}}>
          <div className="grid lg:grid-cols-[1.1fr_1fr] gap-0 items-center">
            <div className="p-10 lg:p-14">
              <div className="inline-flex items-center gap-2 bg-neutral-900 text-white text-xs font-semibold px-3 py-1.5 rounded-full mb-5">
                <span className="w-1.5 h-1.5 rounded-full" style={{background: PBRAND.accent}} />
                Parcours Auto · cas client
              </div>
              <h3 className="text-3xl font-bold text-neutral-900 mb-4 leading-tight">
                De la conversation WhatsApp au paiement — en 4 minutes.
              </h3>
              <p className="text-neutral-500 leading-relaxed mb-6">
                L'IA qualifie, le client choisit sa formule, paie via Wave/OM/MTN, et reçoit son attestation par SMS. Vos équipes pilotent depuis un back-office unifié.
              </p>
              <div className="flex gap-6">
                <Stat v="78 203" u="FCFA / souscription" />
                <Stat v="4 min" u="temps moyen" />
                <Stat v="×3" u="conversion" />
              </div>
            </div>
            <div className="relative p-6 lg:p-10 bg-gradient-to-br from-neutral-50 to-neutral-100 h-full flex items-center">
              <img src="assets/Picture1.png" className="w-full h-auto max-h-[420px] object-contain"
                style={{animation: 'floatTile 6s ease-in-out infinite'}} />
            </div>
          </div>
        </div>

        {/* 3 smaller tiles */}
        <div className="grid lg:grid-cols-3 gap-6">
          <MiniTile
            chip="Conversation"
            title="WhatsApp intelligent"
            desc="L'IA qualifie et répond 24/7. Escalade vers un agent en un clic."
            img="assets/Picture3.png"
          />
          <MiniTile
            chip="Back-office"
            title="Tickets unifiés"
            desc="Toutes les demandes clients dans un inbox, par canal et apporteur."
            img="assets/Picture4.png"
          />
          <MiniTile
            chip="Pilotage"
            title="KPI temps réel"
            desc="Conversions, tickets, encaissements — par canal, équipe, produit."
            img="assets/Picture6.png"
          />
        </div>

        <style>{`
          @keyframes floatTile {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
          }
        `}</style>
      </div>
    </section>
  );
}

function Stat({v, u}) {
  return (
    <div>
      <div className="text-2xl font-bold text-neutral-900 tabular-nums">{v}</div>
      <div className="text-xs text-neutral-500 font-medium">{u}</div>
    </div>
  );
}

function MiniTile({chip, title, desc, img}) {
  return (
    <div className="rounded-2xl bg-white border border-neutral-200 p-6 group cursor-pointer hover:shadow-md transition-all"
      style={{boxShadow: '0 1px 4px rgba(0,0,0,0.04)'}}>
      <div className="aspect-[16/10] rounded-xl overflow-hidden bg-neutral-50 mb-5 flex items-center justify-center p-4 border border-neutral-100">
        <img src={img} className="max-w-full max-h-full object-contain group-hover:scale-105 transition-transform duration-500" />
      </div>
      <div className="text-[11px] font-bold uppercase tracking-widest mb-2" style={{color: PBRAND.accent}}>{chip}</div>
      <h4 className="text-lg font-bold text-neutral-900 mb-1.5">{title}</h4>
      <p className="text-sm text-neutral-500 leading-relaxed">{desc}</p>
    </div>
  );
}

// ── Version C — Phone stack with sliding carousel ──────────
function ProductsC() {
  const phoneSteps = [
    { image: 'assets/Picture3.png', label: 'WhatsApp', sub: 'L\'IA qualifie' },
    { image: 'assets/Picture5.png', label: 'Paiement', sub: 'Wave · OM · MTN · CB' },
    { image: 'assets/Picture1.png', label: 'Back-office', sub: 'Tickets unifiés' },
    { image: 'assets/Picture6.png', label: 'KPI', sub: 'Temps réel' },
  ];
  const [active, setActive] = React.useState(0);

  React.useEffect(() => {
    const t = setInterval(() => setActive(i => (i + 1) % phoneSteps.length), 3800);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="bg-black text-white py-20 px-8 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] rounded-full blur-[120px] opacity-30"
          style={{background: `radial-gradient(circle, ${PBRAND.accent} 0%, transparent 70%)`}} />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="mb-12">
          <span className="inline-block text-xs font-bold uppercase tracking-widest mb-4" style={{color: PBRAND.accent2}}>
            Notre produit · Docaya
          </span>
          <h2 className="text-4xl font-bold leading-[1.1] tracking-tight max-w-3xl">
            De la première question à l'encaissement — en une conversation.
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Phone stage */}
          <div className="relative h-[540px] flex items-center justify-center">
            {phoneSteps.map((p, i) => {
              const offset = i - active;
              const isActive = i === active;
              return (
                <div
                  key={i}
                  className="absolute transition-all duration-700"
                  style={{
                    transform: `translateX(${offset * 60}px) translateY(${Math.abs(offset) * 20}px) scale(${isActive ? 1 : 0.85 - Math.abs(offset)*0.05}) rotateY(${offset * -8}deg)`,
                    opacity: Math.abs(offset) > 2 ? 0 : 1 - Math.abs(offset) * 0.3,
                    zIndex: 10 - Math.abs(offset),
                    filter: isActive ? 'none' : 'brightness(0.7)',
                  }}
                >
                  <div className="rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-white"
                    style={{boxShadow: isActive ? `0 20px 80px ${PBRAND.accent}40` : '0 10px 40px rgba(0,0,0,0.3)'}}>
                    <img src={p.image} className="block max-w-[320px] max-h-[480px] object-contain" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Copy + picker */}
          <div>
            <div className="mb-8">
              <div className="text-sm font-semibold mb-2" style={{color: PBRAND.accent2}}>
                {String(active+1).padStart(2,'0')} / {String(phoneSteps.length).padStart(2,'0')}
              </div>
              <h3 className="text-3xl font-bold mb-3">{phoneSteps[active].label}</h3>
              <p className="text-white/60 text-lg">{phoneSteps[active].sub}</p>
            </div>

            <div className="flex flex-col gap-2">
              {phoneSteps.map((p, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  className="text-left flex items-center gap-4 px-4 py-3 rounded-xl border transition-all"
                  style={{
                    borderColor: i === active ? PBRAND.accent : 'rgba(255,255,255,0.1)',
                    background: i === active ? 'rgba(254,27,0,0.08)' : 'rgba(255,255,255,0.02)',
                  }}
                >
                  <span className="text-xs font-mono tabular-nums" style={{color: i === active ? PBRAND.accent : 'rgba(255,255,255,0.4)'}}>
                    {String(i+1).padStart(2,'0')}
                  </span>
                  <span className={`text-sm font-semibold ${i === active ? 'text-white' : 'text-white/50'}`}>
                    {p.label}
                  </span>
                  <span className="ml-auto text-xs text-white/40">{p.sub}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { ProductsA, ProductsB, ProductsC });
