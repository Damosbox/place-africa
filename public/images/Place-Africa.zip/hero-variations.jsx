// Hero variations — 3 directions
// A. Bulles de conversation flottantes autour du visuel
// B. Aurora + orbites de canaux
// C. Typewriter + mockup produit (remplace la photo)

const BRAND = {
  accent: "#FE1B00",
  accent2: "#FE4D2B",
  accent3: "#FE7055",
};

// ── Shared bits ────────────────────────────────────────────
function Grid() {
  return (
    <div className="absolute inset-0 pointer-events-none opacity-[0.04]">
      <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="heroGrid" width="48" height="48" patternUnits="userSpaceOnUse">
            <path d="M 48 0 L 0 0 0 48" fill="none" stroke="white" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#heroGrid)" />
      </svg>
    </div>
  );
}

function Badges() {
  return (
    <div className="flex flex-wrap items-center gap-2 mb-8">
      <span className="inline-flex items-center gap-2 border border-white/10 rounded-full px-4 py-1.5 text-white/60 text-[13px] font-medium">
        <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{background: BRAND.accent}} />
        Place Africa acquiert <span className="text-white font-semibold">Docaya</span>
        <span className="text-white/30 mx-0.5">·</span>
        <a className="hover:text-orange-400 transition-colors" style={{color: BRAND.accent}}>Lire l'annonce →</a>
      </span>
      <span className="inline-flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1.5 text-white/50 text-xs font-medium">
        <svg width="11" height="11" viewBox="0 0 24 24" fill={BRAND.accent}>
          <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
        </svg>
        Propulsé par l'IA
      </span>
    </div>
  );
}

function CTAs() {
  return (
    <div className="flex flex-col sm:flex-row items-start gap-3 mb-4">
      <button className="inline-flex items-center gap-2 bg-white text-black hover:bg-neutral-100 rounded-lg font-bold px-6 py-3 text-sm" style={{boxShadow: "0 4px 16px rgba(0,0,0,0.20)"}}>
        Nos produits
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
      </button>
      <button className="inline-flex items-center gap-2 text-white/70 hover:text-white hover:bg-white/8 rounded-lg font-semibold px-6 py-3 text-sm">
        Découvrir DOCAYA
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
      </button>
    </div>
  );
}

// ── Hero A — Chat bubbles floating around merchant photo ───
function HeroA() {
  const bubbles = [
    { side: 'left', top: '8%',  delay: 0.3, text: "Bonjour, combien coûte l'assurance auto ?", who: 'user', channel: 'wa' },
    { side: 'right', top: '22%', delay: 1.2, text: "78 203 FCFA / 6 mois • Tiers amélioré", who: 'bot', channel: 'wa' },
    { side: 'left', top: '42%', delay: 2.1, text: "Je prends 👍", who: 'user', channel: 'wa' },
    { side: 'right', top: '58%', delay: 3.0, text: "Paiement Wave confirmé ✓", who: 'bot', channel: 'pay' },
    { side: 'left', top: '76%', delay: 3.9, text: "Votre attestation est prête", who: 'bot', channel: 'sms' },
  ];
  return (
    <div className="relative hidden lg:block h-full">
      {/* Glow */}
      <div className="absolute inset-0 rounded-3xl blur-2xl scale-90 translate-y-4" style={{background: `${BRAND.accent}26`}} />

      {/* Image */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 shadow-2xl aspect-[4/5]">
        <img src="assets/hero-merchant.png" className="w-full h-full object-cover object-center" />
        <div className="absolute inset-0" style={{background: 'linear-gradient(to top, rgba(0,0,0,0.4), transparent 30%, rgba(0,0,0,0.15))'}} />
      </div>

      {/* Floating bubbles */}
      {bubbles.map((b, i) => (
        <div
          key={i}
          className="absolute pointer-events-none"
          style={{
            [b.side]: b.side === 'left' ? '-18%' : '-14%',
            top: b.top,
            animation: `bubbleIn 0.6s cubic-bezier(.2,.9,.3,1) ${b.delay}s both, bubbleFloat 6s ease-in-out ${b.delay + 0.6}s infinite`,
          }}
        >
          <ChatBubble {...b} />
        </div>
      ))}

      <style>{`
        @keyframes bubbleIn {
          0% { opacity: 0; transform: translateY(12px) scale(.9); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes bubbleFloat {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}

function ChatBubble({ text, who, channel }) {
  const isBot = who === 'bot';
  const channelIcon = {
    wa: <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px]" style={{background:'#25D366'}}>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M20.52 3.48A11.78 11.78 0 0012 0C5.37 0 0 5.37 0 12a11.9 11.9 0 001.6 6L0 24l6.17-1.62A11.9 11.9 0 0012 24c6.63 0 12-5.37 12-12a11.78 11.78 0 00-3.48-8.52z"/></svg>
    </span>,
    pay: <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] bg-blue-500">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="white"><path d="M21 4H3a2 2 0 00-2 2v12a2 2 0 002 2h18a2 2 0 002-2V6a2 2 0 00-2-2zM3 6h18v2H3V6zm0 12v-6h18v6H3z"/></svg>
    </span>,
    sms: <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px]" style={{background: BRAND.accent}}>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="white"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
    </span>,
  };

  return (
    <div
      className="flex items-end gap-2 max-w-[260px]"
      style={{ flexDirection: isBot ? 'row' : 'row-reverse' }}
    >
      {channelIcon[channel]}
      <div
        className={`rounded-2xl px-3.5 py-2.5 text-[13px] leading-snug font-medium shadow-lg ${
          isBot ? 'bg-white text-neutral-900 rounded-bl-md' : 'text-white rounded-br-md'
        }`}
        style={!isBot ? { background: BRAND.accent } : {}}
      >
        {text}
      </div>
    </div>
  );
}

// ── Hero B — Aurora + orbiting channels ────────────────────
function HeroB() {
  const channels = [
    { label: 'WhatsApp', color: '#25D366', icon: <svg viewBox="0 0 24 24" fill="white" width="16" height="16"><path d="M20.52 3.48A11.78 11.78 0 0012 0C5.37 0 0 5.37 0 12a11.9 11.9 0 001.6 6L0 24l6.17-1.62A11.9 11.9 0 0012 24c6.63 0 12-5.37 12-12a11.78 11.78 0 00-3.48-8.52z"/></svg>, angle: 0 },
    { label: 'Wave', color: '#1DC8F2', icon: <span className="text-white font-black text-[10px]">W</span>, angle: 60 },
    { label: 'Orange', color: '#FF7900', icon: <span className="text-white font-black text-[10px]">OM</span>, angle: 120 },
    { label: 'SMS', color: BRAND.accent, icon: <svg viewBox="0 0 24 24" fill="white" width="14" height="14"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>, angle: 180 },
    { label: 'Email', color: '#EA4335', icon: <svg viewBox="0 0 24 24" fill="white" width="14" height="14"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>, angle: 240 },
    { label: 'MTN',  color: '#FFCB05', icon: <span className="text-black font-black text-[9px]">MTN</span>, angle: 300 },
  ];
  return (
    <div className="relative hidden lg:flex items-center justify-center h-full">
      {/* Aurora blob animated */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute left-1/2 top-1/2 w-[520px] h-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-[120px] opacity-50"
          style={{ background: `radial-gradient(circle, ${BRAND.accent} 0%, transparent 70%)`, animation: 'auroraA 10s ease-in-out infinite' }} />
        <div className="absolute left-1/2 top-1/2 w-[420px] h-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-[100px] opacity-40"
          style={{ background: `radial-gradient(circle, ${BRAND.accent3} 0%, transparent 70%)`, animation: 'auroraB 13s ease-in-out infinite reverse' }} />
      </div>

      {/* Central merchant card */}
      <div className="relative z-10 w-[340px] aspect-[4/5] rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
        <img src="assets/hero-merchant.png" className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{background: 'linear-gradient(to top, rgba(0,0,0,0.5), transparent 30%)'}} />
      </div>

      {/* Orbiting channels */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative w-[260px] h-[260px]" style={{ animation: 'spin 28s linear infinite' }}>
          {channels.map((c, i) => (
            <div
              key={i}
              className="absolute"
              style={{
                left: '50%', top: '50%',
                transform: `rotate(${c.angle}deg) translate(280px) rotate(-${c.angle}deg)`,
              }}
            >
              <div
                className="flex items-center gap-2 backdrop-blur-md rounded-full pl-1.5 pr-4 py-1.5 border border-white/15 shadow-xl"
                style={{ background: 'rgba(20,20,20,0.8)', animation: `pulse${i} ${3 + i*0.3}s ease-in-out infinite` }}
              >
                <span className="w-7 h-7 rounded-full flex items-center justify-center" style={{background: c.color}}>
                  {c.icon}
                </span>
                <span className="text-white text-xs font-semibold whitespace-nowrap">{c.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes auroraA {
          0%, 100% { transform: translate(-50%, -50%) scale(1); }
          50% { transform: translate(-40%, -60%) scale(1.2); }
        }
        @keyframes auroraB {
          0%, 100% { transform: translate(-50%, -50%) scale(1.1); }
          50% { transform: translate(-60%, -40%) scale(0.9); }
        }
      `}</style>
    </div>
  );
}

// ── Hero C — Product mockup + typewriter ───────────────────
function HeroC() {
  return (
    <div className="relative hidden lg:block h-full">
      {/* Aurora */}
      <div className="absolute -inset-10 pointer-events-none">
        <div className="absolute left-1/2 top-1/2 w-[500px] h-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-[140px] opacity-60"
          style={{ background: `radial-gradient(circle, ${BRAND.accent}66 0%, transparent 70%)`, animation: 'breathe 8s ease-in-out infinite' }} />
      </div>

      {/* Product composite (Picture1 = desktop+phone) */}
      <div className="relative">
        <img
          src="assets/Picture1.png"
          className="relative z-10 w-full"
          style={{ animation: 'floatY 6s ease-in-out infinite' }}
        />

        {/* Floating KPI tiles */}
        <div className="absolute -left-6 top-8 z-20 bg-white rounded-2xl px-4 py-3 shadow-2xl border border-white/20"
          style={{animation: 'floatY 5s ease-in-out infinite', animationDelay: '0.5s'}}>
          <div className="text-[10px] uppercase tracking-wider font-bold text-neutral-400">Tickets ouverts</div>
          <div className="text-2xl font-bold text-neutral-900">318</div>
          <div className="text-[11px] font-semibold" style={{color: BRAND.accent}}>↑ 24% cette semaine</div>
        </div>

        <div className="absolute -right-4 top-1/3 z-20 rounded-2xl px-4 py-3 shadow-2xl text-white"
          style={{background: BRAND.accent, animation: 'floatY 7s ease-in-out infinite', animationDelay: '1.2s'}}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M20.52 3.48A11.78 11.78 0 0012 0C5.37 0 0 5.37 0 12a11.9 11.9 0 001.6 6L0 24l6.17-1.62A11.9 11.9 0 0012 24c6.63 0 12-5.37 12-12a11.78 11.78 0 00-3.48-8.52z"/></svg>
            </div>
            <div>
              <div className="text-[10px] opacity-80 uppercase tracking-wider font-bold">Paiement</div>
              <div className="text-sm font-bold">78 203 FCFA reçus</div>
            </div>
          </div>
        </div>

        <div className="absolute -left-2 bottom-8 z-20 bg-neutral-900 rounded-2xl px-4 py-3 shadow-2xl border border-white/10"
          style={{animation: 'floatY 5.5s ease-in-out infinite', animationDelay: '1.8s'}}>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full animate-pulse" style={{background: '#25D366'}} />
            <span className="text-xs text-white/70 font-medium">IA en conversation</span>
          </div>
          <div className="text-white text-sm font-semibold mt-1">12 clients en ligne</div>
        </div>
      </div>

      <style>{`
        @keyframes floatY {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
        @keyframes breathe {
          0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.6; }
          50% { transform: translate(-50%, -50%) scale(1.15); opacity: 0.8; }
        }
      `}</style>
    </div>
  );
}

// ── Typewriter word rotation ────────────────────────────────
function Typewriter({ words, className, style }) {
  const [idx, setIdx] = React.useState(0);
  const [shown, setShown] = React.useState("");
  const [phase, setPhase] = React.useState('typing');

  React.useEffect(() => {
    const w = words[idx];
    if (phase === 'typing') {
      if (shown.length < w.length) {
        const t = setTimeout(() => setShown(w.slice(0, shown.length + 1)), 60);
        return () => clearTimeout(t);
      } else {
        const t = setTimeout(() => setPhase('deleting'), 1600);
        return () => clearTimeout(t);
      }
    } else {
      if (shown.length > 0) {
        const t = setTimeout(() => setShown(shown.slice(0, -1)), 30);
        return () => clearTimeout(t);
      } else {
        setIdx((idx + 1) % words.length);
        setPhase('typing');
      }
    }
  }, [shown, phase, idx, words]);

  return (
    <span className={className} style={style}>
      {shown}
      <span className="inline-block w-[3px] align-middle ml-1 animate-pulse" style={{height: '0.9em', background: 'currentColor'}} />
    </span>
  );
}

// ── Hero frames (wrap the 3 variations in a reusable shell) ─
function HeroFrame({ variation }) {
  const headline = variation === 'C' ? (
    <>
      Les{" "}
      <Typewriter
        words={["apps", "chatbots", "paiements", "campagnes"]}
        className="gradient-text inline-block"
        style={{minWidth: '3ch'}}
      />
      {" "}qui font tourner<br />l'Afrique.
    </>
  ) : (
    <>
      Les <span className="gradient-text">apps</span> qui font tourner<br />l'Afrique.
    </>
  );

  return (
    <section className="relative flex flex-col overflow-hidden bg-black" style={{ minHeight: 820 }}>
      <Grid />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-[30%] w-[500px] h-[500px] rounded-full blur-[140px]" style={{background: `${BRAND.accent}14`}} />
      </div>

      <div className="flex-1 flex items-center px-12 pt-28 pb-16 relative z-10">
        <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          <div>
            <Badges />
            <h1 className="text-5xl xl:text-6xl font-bold text-white leading-[1.05] tracking-tight mb-6">
              {headline}
            </h1>
            <p className="text-sm text-white/60 leading-relaxed max-w-lg mb-10 font-medium">
              Docaya, l'outil qui permet à vos équipes de répondre à tous vos clients et de leur envoyer le bon message — sur WhatsApp, SMS, e-mail et paiement mobile.
            </p>
            <CTAs />
          </div>
          {variation === 'A' && <HeroA />}
          {variation === 'B' && <HeroB />}
          {variation === 'C' && <HeroC />}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { HeroFrame, HeroA, HeroB, HeroC, Typewriter });
